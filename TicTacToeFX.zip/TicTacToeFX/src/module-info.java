module com.example {
    requires javafx.controls;
    exports com.example;
}
